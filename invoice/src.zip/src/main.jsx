import React from "react";
import ReactDOM from "react-dom/client";
import App from "./App";
import { invoke } from '@tauri-apps/api';  

async function startBackend() {
  try {
    await invoke('start_backend');  
    console.log('Backend started successfully');
  } catch (error) {
    console.error('Failed to start backend:', error);
  }
}


startBackend();


ReactDOM.createRoot(document.getElementById("root")).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
